import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1 style={{ color: 'red' }}>안녕하세요</h1>
      <p className="pStyle">잘 지내시죠?</p>
      <button>버튼</button>
    </div>
  );
}

export default App;
