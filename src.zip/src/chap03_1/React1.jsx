import React from "react";

function React1(){
    return(
        <div>React!!!</div>

    )
}

export default React1;
