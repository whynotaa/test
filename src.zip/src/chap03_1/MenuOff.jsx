import React from "react";

function MenuOff(){
    return(
        <div style={{border: '1px solid green'}}>
            <h1> 메뉴...1</h1>
            <p>준비중</p>
        </div>
    );
}

export default MenuOff;
